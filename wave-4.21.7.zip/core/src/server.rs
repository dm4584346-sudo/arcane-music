//! The local server of the app (was node/server.cjs), 127.0.0.1 only:
//!   GET  /ui/…                 the interface (static files)
//!   POST /api/call             { cmd, data } → { ok, value } | { ok: false, error }   (header X-Wave-Key)
//!   GET  /api/events?k=KEY     server-sent events: «wave:event» of the core + native requests
//!   POST /api/window           an address of the sign-in screen (or its closing)
//!   POST /api/upload?name=…    a file picked with the Android picker
//!   GET  /px/KEY/?u=…          HLS / picture proxy for the known CDNs (CORS for hls.js, Web Audio, canvas)
//!   GET  /m/KEY/<host>/<path>  wave-media://<host>/<path> (own files, decrypted Yandex stream), Range-aware
//!   GET  /health
//! plus http://127.0.0.1:43821/callback for the Spotify sign-in in the phone's browser.

use crate::app::{app, blog, fix_urls, log, unfix_urls};
use crate::js::{J, R};
use crate::re;
use crate::resp::{channel, Body as RBody, Resp};
use bytes::Bytes;
use futures_util::TryStreamExt;
use http_body_util::{combinators::UnsyncBoxBody, BodyExt, Empty, Full, StreamBody};
use hyper::body::{Frame, Incoming};
use hyper::server::conn::http1;
use hyper::service::service_fn;
use hyper::{Request, Response};
use hyper_util::rt::TokioIo;
use serde_json::{json, Value};
use std::convert::Infallible;
use std::path::{Component, PathBuf};
use std::time::Duration;

type Body = UnsyncBoxBody<Bytes, std::io::Error>;

fn full(b: impl Into<Bytes>) -> Body {
    Full::new(b.into()).map_err(|n: Infallible| match n {}).boxed_unsync()
}
fn empty() -> Body {
    Empty::new().map_err(|n: Infallible| match n {}).boxed_unsync()
}
fn to_response(r: Resp, head: bool) -> Response<Body> {
    let mut b = Response::builder().status(r.status);
    for (k, v) in &r.headers {
        b = b.header(k.as_str(), v.as_str());
    }
    let body = if head {
        empty()
    } else {
        match r.body {
            RBody::Empty => empty(),
            RBody::Bytes(x) => full(x),
            RBody::Stream(s) => BodyExt::boxed_unsync(StreamBody::new(s.map_ok(Frame::data))),
        }
    };
    b.body(body).unwrap_or_else(|_| Response::new(empty()))
}
fn status(code: u16) -> Response<Body> {
    to_response(Resp::empty(code), false)
}
fn json_resp(code: u16, v: &Value) -> Response<Body> {
    let body = fix_urls(&v.to_string());
    Response::builder()
        .status(code)
        .header("Content-Type", "application/json; charset=utf-8")
        .header("Cache-Control", "no-store")
        .body(full(body))
        .unwrap()
}

async fn read_body(req: Request<Incoming>, limit: usize) -> Option<Bytes> {
    let mut body = req.into_body();
    let mut out = Vec::new();
    while let Some(f) = body.frame().await {
        let f = f.ok()?;
        if let Some(d) = f.data_ref() {
            out.extend_from_slice(d);
            if out.len() > limit {
                return None;
            }
        }
    }
    Some(Bytes::from(out))
}

fn key_ok(req: &Request<Incoming>) -> bool {
    req.headers().get("x-wave-key").and_then(|v| v.to_str().ok()) == Some(app().key.as_str())
}
fn query(req: &Request<Incoming>, k: &str) -> Option<String> {
    let q = req.uri().query()?;
    url::form_urlencoded::parse(q.as_bytes()).find(|(a, _)| a == k).map(|(_, v)| v.into_owned())
}

async fn api_call(req: Request<Incoming>) -> Response<Body> {
    if !key_ok(&req) {
        return json_resp(403, &json!({ "ok": false, "error": "forbidden" }));
    }
    let Some(b) = read_body(req, 8 * 1024 * 1024).await else {
        return json_resp(400, &json!({ "ok": false, "error": "bad request" }));
    };
    let msg: Value = if b.is_empty() {
        json!({})
    } else {
        match serde_json::from_slice(&b) {
            Ok(v) => v,
            Err(_) => return json_resp(400, &json!({ "ok": false, "error": "bad request" })),
        }
    };
    let cmd = msg.g("cmd").s();
    let data = if msg.g("data").is_object() || msg.g("data").is_array() { unfix_urls(msg.g("data").clone()) } else { json!({}) };
    // a command runs in its own task: a dropped connection must not cancel what it writes to the library
    let task = tokio::spawn(async move { crate::commands::call(&cmd, data).await });
    let r: R<Value> = match task.await {
        Ok(r) => r,
        Err(e) => Err(crate::js::E::new(format!("Внутренняя ошибка: {}", e))),
    };
    match r {
        Ok(v) => json_resp(200, &json!({ "ok": true, "value": v })),
        Err(e) => json_resp(200, &json!({ "ok": false, "error": e.msg })),
    }
}

fn events(req: &Request<Incoming>) -> Response<Body> {
    if query(req, "k").as_deref() != Some(app().key.as_str()) {
        return status(403);
    }
    let mut rx = app().events.subscribe();
    let (tx, body) = channel(64);
    tokio::spawn(async move {
        if tx.send(Ok(Bytes::from_static(b": hello\n\n"))).await.is_err() {
            return;
        }
        let mut ping = tokio::time::interval(Duration::from_secs(25));
        ping.tick().await;
        loop {
            tokio::select! {
                m = rx.recv() => match m {
                    Ok(line) => if tx.send(Ok(Bytes::from(line))).await.is_err() { return },
                    Err(tokio::sync::broadcast::error::RecvError::Lagged(_)) => continue,
                    Err(_) => return,
                },
                _ = ping.tick() => if tx.send(Ok(Bytes::from_static(b": ping\n\n"))).await.is_err() { return },
                _ = tx.closed() => return,
            }
        }
    });
    Response::builder()
        .status(200)
        .header("Content-Type", "text/event-stream")
        .header("Cache-Control", "no-store")
        .header("Connection", "keep-alive")
        .body(BodyExt::boxed_unsync(StreamBody::new(body.map_ok(Frame::data))))
        .unwrap()
}

async fn auth_window(req: Request<Incoming>) -> Response<Body> {
    if !key_ok(&req) {
        return json_resp(403, &json!({ "ok": false }));
    }
    let Some(b) = read_body(req, 64 * 1024).await else { return json_resp(400, &json!({ "ok": false })) };
    let Ok(m) = serde_json::from_slice::<Value>(&b) else { return json_resp(400, &json!({ "ok": false })) };
    let id = m.g("id").sv();
    if m.g("closed").truthy() {
        crate::windows::close(&id);
    } else if let Some(u) = m.g("url").as_str() {
        crate::windows::nav(&id, u);
    }
    json_resp(200, &json!({ "ok": true }))
}

async fn upload(req: Request<Incoming>) -> Response<Body> {
    if !key_ok(&req) {
        return json_resp(403, &json!({ "ok": false }));
    }
    let up = app().data.join("upload");
    let reset = query(&req, "reset").map(|v| !v.is_empty()).unwrap_or(false);
    let raw = query(&req, "name").unwrap_or_else(|| "file".into());
    let r: Result<usize, String> = async {
        if reset {
            app().pending_files.lock().unwrap().clear();
            let _ = tokio::fs::remove_dir_all(&up).await;
        }
        tokio::fs::create_dir_all(&up).await.map_err(|e| e.to_string())?;
        let name: String = raw.chars().map(|c| if "\\/:*?\"<>|".contains(c) || (c as u32) < 0x20 { '_' } else { c }).collect();
        let name = crate::js::slice_end(&name, 120);
        let dir = up.join(format!("f{}", hex::encode(rand::random::<[u8; 6]>())));
        tokio::fs::create_dir_all(&dir).await.map_err(|e| e.to_string())?;
        let file = dir.join(if name.is_empty() { "file".to_string() } else { name });
        let mut out = tokio::fs::File::create(&file).await.map_err(|e| e.to_string())?;
        let mut body = req.into_body();
        let mut n = 0usize;
        use tokio::io::AsyncWriteExt;
        while let Some(f) = body.frame().await {
            let f = f.map_err(|e| e.to_string())?;
            if let Some(d) = f.data_ref() {
                n += d.len();
                if n > 300 * 1024 * 1024 {
                    return Err("Файл больше 300 МБ".to_string());
                }
                out.write_all(d).await.map_err(|e| e.to_string())?;
            }
        }
        out.flush().await.map_err(|e| e.to_string())?;
        let mut p = app().pending_files.lock().unwrap();
        p.push(file);
        Ok(p.len())
    }
    .await;
    match r {
        Ok(count) => json_resp(200, &json!({ "ok": true, "count": count })),
        Err(e) => json_resp(200, &json!({ "ok": false, "error": e })),
    }
}

/* ---------- HLS / picture proxy ---------- */
fn hls_host(h: &str) -> bool {
    re!(r"(?i)(^|\.)(sndcdn\.com|soundcloud\.cloud|soundcloud\.com|audius\.co|audius\.org|audius\.network|googlevideo\.com|yandex\.net|yandex\.ru|ytimg\.com|googleusercontent\.com|ggpht\.com|scdn\.co|spotifycdn\.com|lrclib\.net|genius\.com|deezer\.com|dzcdn\.net)$").is_match(h)
}
fn hls_url(u: &str) -> String {
    format!("/px/{}/?u={}", app().key, crate::js::enc(u))
}
/// 4.20: YouTube audio (googlevideo) answers only bounded ranges of at most ~1 MB now — an open range, no range or a
/// big one gets 403. The player asks for «bytes=N-» as usual; the file is fetched here piece by piece and given out as
/// one continuous answer (206 with Content-Range, so seeking works).
const YT_CHUNK: u64 = 1 << 20;
async fn yt_piece(url: &str, a: u64, b: u64) -> Option<reqwest::Response> {
    let r = crate::http::RAW
        .get(url)
        .header("User-Agent", crate::http::UA)
        .header("Range", format!("bytes={}-{}", a, b))
        .timeout(std::time::Duration::from_secs(30))
        .send()
        .await
        .ok()?;
    if r.status().as_u16() == 206 || r.status().is_success() {
        Some(r)
    } else {
        None
    }
}
async fn yt_proxy(target: url::Url, range: Option<String>) -> Response<Body> {
    let url = target.to_string();
    let mut total: Option<u64> = target.query_pairs().find(|(k, _)| k == "clen").and_then(|(_, v)| v.parse().ok());
    // the client range
    let m = range.as_deref().and_then(|r| re!(r"^bytes=(\d*)-(\d*)$").captures(r.trim()).map(|c| (c[1].to_string(), c[2].to_string())));
    let mut first = None;
    if total.is_none() {
        let Some(r) = yt_piece(&url, 0, YT_CHUNK - 1).await else { return status(502) };
        total = r
            .headers()
            .get("content-range")
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.rsplit('/').next())
            .and_then(|v| v.trim().parse().ok());
        first = Some(r);
    }
    let Some(total) = total.filter(|t| *t > 0) else { return status(502) };
    let (start, end) = match &m {
        Some((a, b)) if !a.is_empty() => (a.parse::<u64>().unwrap_or(0), if b.is_empty() { total - 1 } else { b.parse::<u64>().unwrap_or(total - 1).min(total - 1) }),
        Some((_, b)) if !b.is_empty() => (total.saturating_sub(b.parse::<u64>().unwrap_or(0)), total - 1),
        _ => (0, total - 1),
    };
    if start > end || start >= total {
        return Response::builder()
            .status(416)
            .header("Content-Range", format!("bytes */{}", total))
            .header("Access-Control-Allow-Origin", "*")
            .body(empty())
            .unwrap();
    }
    let first = match first {
        Some(r) if start == 0 => r,
        _ => match yt_piece(&url, start, (start + YT_CHUNK - 1).min(end)).await {
            Some(r) => r,
            None => return status(502),
        },
    };
    let ty = first.headers().get("content-type").and_then(|v| v.to_str().ok()).unwrap_or("audio/webm").to_string();
    let (tx, body) = channel(16);
    tokio::spawn(async move {
        let mut pos = start;
        let mut cur = Some(first);
        while pos <= end {
            let mut r = match cur.take() {
                Some(r) => r,
                None => match yt_piece(&url, pos, (pos + YT_CHUNK - 1).min(end)).await {
                    Some(r) => r,
                    None => {
                        let _ = tx.send(Err(std::io::Error::other("upstream"))).await;
                        return;
                    }
                },
            };
            let piece_end = (pos + YT_CHUNK - 1).min(end);
            let mut got = 0u64;
            let want = piece_end - pos + 1;
            loop {
                match r.chunk().await {
                    Ok(Some(b)) => {
                        let take = (want - got).min(b.len() as u64) as usize;
                        if take == 0 {
                            break;
                        }
                        got += take as u64;
                        if tx.send(Ok(b.slice(..take))).await.is_err() {
                            return; // the player went away
                        }
                        if got >= want {
                            break;
                        }
                    }
                    Ok(None) => break,
                    Err(_) => {
                        let _ = tx.send(Err(std::io::Error::other("upstream"))).await;
                        return;
                    }
                }
            }
            if got == 0 {
                let _ = tx.send(Err(std::io::Error::other("upstream ended"))).await;
                return;
            }
            pos += got;
        }
    });
    let mut b = Response::builder()
        .status(if range.is_some() { 206 } else { 200 })
        .header("Content-Type", ty)
        .header("Accept-Ranges", "bytes")
        .header("Access-Control-Allow-Origin", "*")
        .header("Cache-Control", "no-store")
        .header("Content-Length", (end - start + 1).to_string());
    if range.is_some() {
        b = b.header("Content-Range", format!("bytes {}-{}/{}", start, end, total));
    }
    b.body(BodyExt::boxed_unsync(StreamBody::new(body.map_ok(Frame::data)))).unwrap()
}

async fn hls_proxy(req: Request<Incoming>) -> Response<Body> {
    let Some(target) = query(&req, "u").and_then(|u| url::Url::parse(&u).ok()) else { return status(400) };
    if target.scheme() != "https" || !target.host_str().map(hls_host).unwrap_or(false) {
        return status(403);
    }
    if target.host_str().map(|h| h.ends_with("googlevideo.com")).unwrap_or(false) {
        let range = req.headers().get("range").and_then(|v| v.to_str().ok()).map(String::from);
        return yt_proxy(target, range).await;
    }
    let mut rq = crate::http::RAW.get(target.as_str()).header("User-Agent", crate::http::UA);
    if let Some(r) = req.headers().get("range") {
        rq = rq.header("Range", r.clone());
    }
    let Ok(r) = rq.send().await else { return status(502) };
    let st = r.status().as_u16();
    let ty = r.headers().get("content-type").and_then(|v| v.to_str().ok()).unwrap_or("").to_string();
    let is_list = re!(r"(?i)mpegurl").is_match(&ty) || re!(r"(?i)\.m3u8($|\?)").is_match(target.path());
    if is_list {
        let text = r.text().await.unwrap_or_default();
        let abs = |u: &str| target.join(u).map(|x| hls_url(x.as_str())).unwrap_or_else(|_| u.to_string());
        let out: Vec<String> = re!(r"\r?\n")
            .split(&text)
            .map(|line| {
                if line.is_empty() {
                    return String::new();
                }
                if line.starts_with('#') {
                    return re!(r#"URI="([^"]+)""#).replace_all(line, |c: &regex::Captures| format!("URI=\"{}\"", abs(&c[1]))).into_owned();
                }
                abs(line.trim())
            })
            .collect();
        return Response::builder()
            .status(st)
            .header("Access-Control-Allow-Origin", "*")
            .header("Cache-Control", "no-store")
            .header("Content-Type", "application/vnd.apple.mpegurl")
            .body(full(out.join("\n")))
            .unwrap();
    }
    let mut b = Response::builder()
        .status(st)
        .header("Access-Control-Allow-Origin", "*")
        .header("Cache-Control", "no-store")
        .header("Content-Type", if ty.is_empty() { "application/octet-stream".to_string() } else { ty });
    for k in ["content-length", "content-range", "accept-ranges"] {
        if let Some(v) = r.headers().get(k) {
            b = b.header(k, v.clone());
        }
    }
    let s = r.bytes_stream().map_err(std::io::Error::other);
    b.body(BodyExt::boxed_unsync(StreamBody::new(s.map_ok(Frame::data)))).unwrap()
}

/* ---------- wave-media:// ---------- */
async fn serve_media(rest: &str, range: Option<String>) -> Resp {
    let (host, path) = rest.split_once('/').unwrap_or((rest, ""));
    let name = crate::js::dec(path.trim_start_matches('/'));
    if host == "ym" {
        let e = if re!(r"^[a-f0-9]{24}$").is_match(&name) { crate::providers::ymfile::entry(&name) } else { None };
        return match e {
            Some(e) => crate::providers::ymfile::serve_decrypted(e, range.as_deref()).await,
            None => Resp::text(404, "not found"),
        };
    }
    if host != "media" || !crate::engine::media_name_ok(&name) {
        return Resp::text(404, "not found");
    }
    let file = app().data.join("media").join(&name);
    let Ok(md) = tokio::fs::metadata(&file).await else { return Resp::text(404, "not found") };
    let size = md.len();
    let ext = name.rsplit('.').next().unwrap_or("");
    let base = |r: Resp| {
        r.h("Content-Type", crate::engine::mime_of(ext))
            .h("Accept-Ranges", "bytes")
            .h("Access-Control-Allow-Origin", "*")
            .h("Cache-Control", "no-cache")
    };
    let open = |start: u64, len: u64| {
        let file = file.clone();
        async move {
            use tokio::io::{AsyncReadExt, AsyncSeekExt};
            let mut f = tokio::fs::File::open(&file).await.ok()?;
            f.seek(std::io::SeekFrom::Start(start)).await.ok()?;
            let s = tokio_util::io::ReaderStream::new(f.take(len));
            Some(RBody::Stream(Box::pin(s)))
        }
    };
    if let Some(range) = range {
        let m = re!(r"^bytes=(\d*)-(\d*)$").captures(range.trim()).map(|c| (c[1].to_string(), c[2].to_string()));
        let mut start: i64 = -1;
        let mut end: i64 = size as i64 - 1;
        if let Some((a, b)) = &m {
            if !a.is_empty() {
                start = a.parse().unwrap_or(-1);
                if !b.is_empty() {
                    end = end.min(b.parse().unwrap_or(end));
                }
            } else if !b.is_empty() {
                start = (size as i64 - b.parse::<i64>().unwrap_or(0)).max(0);
            }
        }
        if start < 0 || start > end || start as u64 >= size {
            return base(Resp::empty(416)).h("Content-Range", &format!("bytes */{}", size));
        }
        let len = (end - start + 1) as u64;
        let Some(body) = open(start as u64, len).await else { return Resp::text(404, "not found") };
        return base(Resp { status: 206, headers: vec![], body })
            .h("Content-Range", &format!("bytes {}-{}/{}", start, end, size))
            .h("Content-Length", &len.to_string());
    }
    let Some(body) = open(0, size).await else { return Resp::text(404, "not found") };
    base(Resp { status: 200, headers: vec![], body }).h("Content-Length", &size.to_string())
}

/* ---------- static files of the interface ---------- */
fn mime(ext: &str) -> &'static str {
    match ext {
        "html" => "text/html; charset=utf-8",
        "js" => "text/javascript; charset=utf-8",
        "css" => "text/css; charset=utf-8",
        "json" => "application/json",
        "png" => "image/png",
        "svg" => "image/svg+xml",
        "ttf" => "font/ttf",
        "woff2" => "font/woff2",
        "ico" => "image/x-icon",
        "webp" => "image/webp",
        _ => "application/octet-stream",
    }
}
async fn static_file(rel: &str) -> Response<Body> {
    let rel = if rel.is_empty() { "index.html" } else { rel };
    let p = PathBuf::from(rel);
    if p.components().any(|c| !matches!(c, Component::Normal(_))) {
        return status(403);
    }
    let file = app().ui.join(p);
    let Ok(md) = tokio::fs::metadata(&file).await else {
        return Response::builder().status(404).body(full("not found")).unwrap();
    };
    if !md.is_file() {
        return Response::builder().status(404).body(full("not found")).unwrap();
    }
    let Ok(f) = tokio::fs::File::open(&file).await else { return status(404) };
    let ext = file.extension().map(|e| e.to_string_lossy().to_lowercase()).unwrap_or_default();
    Response::builder()
        .status(200)
        .header("Content-Type", mime(&ext))
        .header("Content-Length", md.len())
        .header("Cache-Control", "no-cache")
        .body(BodyExt::boxed_unsync(StreamBody::new(tokio_util::io::ReaderStream::new(f).map_ok(Frame::data))))
        .unwrap()
}

async fn handle(req: Request<Incoming>) -> Result<Response<Body>, Infallible> {
    let p = req.uri().path().to_string();
    let post = req.method() == hyper::Method::POST;
    let head = req.method() == hyper::Method::HEAD;
    let key = app().key.clone();
    let r = if p == "/api/call" && post {
        api_call(req).await
    } else if p == "/api/events" {
        events(&req)
    } else if p == "/api/window" && post {
        auth_window(req).await
    } else if p == "/api/upload" && post {
        upload(req).await
    } else if p.starts_with("/hls/") || p.starts_with("/px/") {
        if p.split('/').nth(2) != Some(key.as_str()) {
            status(403)
        } else {
            hls_proxy(req).await
        }
    } else if let Some(rest) = p.strip_prefix("/m/") {
        let mut parts = rest.splitn(2, '/');
        if parts.next() != Some(key.as_str()) {
            status(403)
        } else {
            let rest = parts.next().unwrap_or("").to_string();
            let range = req.headers().get("range").and_then(|v| v.to_str().ok()).map(String::from);
            to_response(serve_media(&rest, range).await, head)
        }
    } else if p == "/" || p == "/ui" || p == "/ui/" {
        static_file("index.html").await
    } else if let Some(rel) = p.strip_prefix("/ui/") {
        static_file(&crate::js::dec(rel)).await
    } else if p == "/health" {
        Response::builder().status(200).header("Content-Type", "text/plain").body(full("ok")).unwrap()
    } else {
        status(404)
    };
    Ok(r)
}

/* ---------- Spotify sign-in in the phone's browser ---------- */
const SP_PORT: u16 = 43821;
fn back_page(ok: bool, text: &str) -> String {
    format!(
        "<!doctype html><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>Wave</title>\
<body style=\"margin:0;min-height:100vh;display:flex;flex-direction:column;align-items:center;justify-content:center;gap:22px;\
background:#0d0b12;color:#eee;font-family:sans-serif;text-align:center;padding:24px;box-sizing:border-box\">\
<div style=\"font-size:54px\">{}</div><h2 style=\"margin:0\">{}</h2>\
<a href=\"intent://back#Intent;scheme=waveapp;package=app.wave.mobile;end\" style=\"padding:16px 28px;border-radius:14px;\
background:#8b5cf6;color:#fff;text-decoration:none;font-size:18px\">Вернуться в Wave</a>\
<script>setTimeout(function(){{location.href=\"intent://back#Intent;scheme=waveapp;package=app.wave.mobile;end\"}},700)</script></body>",
        if ok { "✓" } else { "!" },
        text
    )
}
async fn spotify_callback(req: Request<Incoming>) -> Result<Response<Body>, Infallible> {
    let pq = req.uri().path_and_query().map(|x| x.as_str().to_string()).unwrap_or_default();
    let full_url = format!("http://127.0.0.1:{}{}", SP_PORT, pq);
    let Ok(u) = url::Url::parse(&full_url) else { return Ok(status(400)) };
    if u.path() != "/callback" {
        return Ok(status(404));
    }
    let w = crate::windows::newest();
    if let Some(id) = &w {
        crate::windows::nav(id, &full_url);
    }
    let has = |k: &str| u.query_pairs().any(|(a, _)| a == k);
    let ok = w.is_some() && has("code");
    let text = if ok {
        "Возвращайтесь в Wave и проверьте результат входа"
    } else if u.query_pairs().any(|(a, v)| a == "error" && !v.is_empty()) {
        "Доступ не выдан"
    } else {
        "Вход в Spotify уже не ждёт ответа — начните его в Wave заново"
    };
    Ok(Response::builder()
        .status(200)
        .header("Content-Type", "text/html; charset=utf-8")
        .header("Cache-Control", "no-store")
        .body(full(back_page(ok, text)))
        .unwrap())
}

async fn serve<F, Fut>(listener: tokio::net::TcpListener, f: F)
where
    F: Fn(Request<Incoming>) -> Fut + Copy + Send + Sync + 'static,
    Fut: std::future::Future<Output = Result<Response<Body>, Infallible>> + Send + 'static,
{
    loop {
        let Ok((stream, _)) = listener.accept().await else { continue };
        let _ = stream.set_nodelay(true);
        tokio::spawn(async move {
            let _ = http1::Builder::new().keep_alive(true).serve_connection(TokioIo::new(stream), service_fn(f)).await;
        });
    }
}

pub async fn run() -> std::io::Result<()> {
    let a = app();
    match tokio::net::TcpListener::bind(("127.0.0.1", SP_PORT)).await {
        Ok(l) => {
            tokio::spawn(serve(l, spotify_callback));
        }
        Err(e) => log(&format!("spotify callback port: {}", e)),
    }
    let l = tokio::net::TcpListener::bind(("127.0.0.1", a.port)).await?;
    log(&format!("listening on {}", a.port));
    blog(&format!("rust core {} started", a.version));
    serve(l, handle).await;
    Ok(())
}

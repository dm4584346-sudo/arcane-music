//! YouTube Music — an extra source of full versions (InnerTube search of music.youtube.com, direct audio URLs from
//! the player of the visionOS / Android VR / iOS clients). Experimental, like on the PC.

use crate::http::{get_json, Opts};
use crate::js::{dec, jn, now_ms, round, slice, J, E, R};
use crate::re;
use serde_json::{json, Map, Value};
use std::collections::HashMap;
use std::sync::{LazyLock, Mutex};

const SEARCH: &str = "https://music.youtube.com/youtubei/v1/search?prettyPrint=false";
const PLAYER: &str = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false";
const SONGS: &str = "EgWKAQIIAWoKEAkQBRAKEAMQBA%3D%3D";
const VIDEOS: &str = "EgWKAQIQAWoKEAkQChAFEAMQBA%3D%3D";
const REMIX_VERSION: &str = "1.20260707.12.00";

fn remix() -> Value {
    json!({ "clientName": "WEB_REMIX", "clientVersion": REMIX_VERSION, "hl": "ru", "gl": "RU" })
}
fn clients() -> Vec<(Value, &'static str)> {
    vec![
        (
            json!({
                "clientName": "VISIONOS", "clientVersion": "1.02", "deviceMake": "Apple", "deviceModel": "RealityDevice17,1",
                "userAgent": "Mozilla/5.0 (Macintosh; Intel Mac OS X 15_7_3) AppleWebKit/605.1.15 (KHTML, like Gecko) Version/26.0 Safari/605.1.15",
                "osName": "visionOS", "osVersion": "26.5.23O471", "hl": "ru", "gl": "RU"
            }),
            "101",
        ),
        (
            json!({
                "clientName": "ANDROID_VR", "clientVersion": "1.65.10", "deviceMake": "Oculus", "deviceModel": "Quest 3",
                "androidSdkVersion": 32,
                "userAgent": "com.google.android.apps.youtube.vr.oculus/1.65.10 (Linux; U; Android 12L; eureka-user Build/SQ3A.220605.009.A1) gzip",
                "osName": "Android", "osVersion": "12L", "hl": "ru", "gl": "RU"
            }),
            "28",
        ),
        (
            json!({
                "clientName": "IOS", "clientVersion": "20.10.4", "deviceMake": "Apple", "deviceModel": "iPhone16,2",
                "userAgent": "com.google.ios.youtube/20.10.4 (iPhone16,2; U; CPU iOS 18_3_2 like Mac OS X;)",
                "osName": "iPhone", "osVersion": "18.3.2.22D82", "hl": "ru", "gl": "RU"
            }),
            "5",
        ),
    ]
}

static VISITOR: Mutex<String> = Mutex::new(String::new());

fn txt(x: &Value) -> String {
    x.g("runs").arr().iter().map(|r| r.g("text").s()).collect()
}
fn secs(s: &str) -> f64 {
    s.split(':').fold(0.0, |a, b| {
        let n = crate::js::str_num(b);
        a * 60.0 + if n.is_nan() { 0.0 } else { n }
    })
}
fn best_thumb(list: &Value) -> Value {
    let t = list.arr().last().map(|x| x.g("url").s()).unwrap_or_default();
    if t.starts_with("https://") {
        json!(re!(r"(?i)=w\d+-h\d+(-[a-z0-9-]+)?$").replacen(&t, 1, "=w544-h544-l90-rj"))
    } else {
        Value::Null
    }
}

fn song(it: &Value) -> Option<Value> {
    let r = it.g("musicResponsiveListItemRenderer");
    if !r.truthy() {
        return None;
    }
    let cols: Vec<&Value> =
        r.g("flexColumns").arr().iter().map(|c| c.path(&["musicResponsiveListItemFlexColumnRenderer", "text"])).collect();
    let col = |i: usize| cols.get(i).copied().unwrap_or(&crate::js::NULL);
    let id = [
        r.path(&["playlistItemData", "videoId"]),
        col(0).path(&["runs", "0", "navigationEndpoint", "watchEndpoint", "videoId"]),
        r.path(&[
            "overlay",
            "musicItemThumbnailOverlayRenderer",
            "content",
            "musicPlayButtonRenderer",
            "playNavigationEndpoint",
            "watchEndpoint",
            "videoId",
        ]),
    ]
    .into_iter()
    .find(|v| v.truthy())
    .map(|v| v.s())
    .unwrap_or_default();
    if !re!(r"^[A-Za-z0-9_-]{11}$").is_match(&id) {
        return None;
    }
    let title = txt(col(0)).trim().to_string();
    let runs = col(1).g("runs").arr();
    let mut parts: Vec<Vec<&Value>> = vec![];
    let mut cur = vec![];
    for x in runs {
        if re!(r"^\s*[•·]\s*$").is_match(&x.g("text").s()) {
            parts.push(std::mem::take(&mut cur));
        } else {
            cur.push(x);
        }
    }
    parts.push(cur);
    let artists: Vec<Value> = parts
        .first()
        .map(|p| {
            p.iter()
                .filter(|x| !re!(r"(?i)^\s*(,|&|и|and|feat\.?|ft\.?)\s*$").is_match(&x.g("text").s()))
                .map(|x| x.g("text").s().trim().to_string())
                .filter(|n| !n.is_empty())
                .map(|n| json!({ "name": n }))
                .collect()
        })
        .unwrap_or_default();
    let dur = parts
        .iter()
        .rev()
        .find(|p| p.len() == 1 && re!(r"^\d{1,2}(:\d{2}){1,2}$").is_match(p[0].g("text").s().trim()))
        .map(|p| secs(p[0].g("text").s().trim()));
    let explicit = r
        .g("badges")
        .arr()
        .iter()
        .any(|b| b.path(&["musicInlineBadgeRenderer", "icon", "iconType"]).as_str() == Some("MUSIC_EXPLICIT_BADGE"));
    if title.is_empty() || artists.is_empty() {
        return None;
    }
    let names: Vec<String> = artists.iter().map(|a| a.g("name").s()).collect();
    Some(json!({
        "id": format!("yt:{}", id),
        "source": "youtube",
        "title": slice(&title, 200),
        "artist": slice(&names.join(", "), 200),
        "artists": artists.into_iter().take(6).collect::<Vec<_>>(),
        "duration": jn(dur.unwrap_or(0.0)),
        "cover": best_thumb(r.path(&["thumbnail", "musicThumbnailRenderer", "thumbnail", "thumbnails"])),
        "link": format!("https://music.youtube.com/watch?v={}", id),
        "explicit": explicit,
        "preview": false,
        "streamable": true,
        "q": "yt",
    }))
}

fn shelves(r: &Value) -> Vec<Value> {
    let tabs = r.path(&["contents", "tabbedSearchResultsRenderer", "tabs"]);
    tabs.at(0)
        .path(&["tabRenderer", "content", "sectionListRenderer", "contents"])
        .arr()
        .iter()
        .flat_map(|s| s.path(&["musicShelfRenderer", "contents"]).arr().to_vec())
        .collect()
}

pub async fn search(text: &str, limit: usize, videos: bool) -> R<Vec<Value>> {
    let q = slice(text.trim(), 150);
    if q.is_empty() {
        return Ok(vec![]);
    }
    let body = json!({ "context": { "client": remix() }, "query": q, "params": dec(if videos { VIDEOS } else { SONGS }) });
    let r = get_json(
        SEARCH,
        Opts::new()
            .timeout(10000)
            .h("Content-Type", "application/json")
            .h("Origin", "https://music.youtube.com")
            .h("Referer", "https://music.youtube.com/")
            .h("X-YouTube-Client-Name", "67")
            .h("X-YouTube-Client-Version", REMIX_VERSION)
            .post(body.to_string()),
    )
    .await?;
    if let Some(vd) = r.path(&["responseContext", "visitorData"]).as_str() {
        if re!(r"^[A-Za-z0-9%_=-]{10,200}$").is_match(vd) {
            *VISITOR.lock().unwrap() = vd.to_string();
        }
    }
    let mut list: Vec<Value> = shelves(&r).iter().filter_map(song).collect();
    if videos {
        for v in list.iter_mut() {
            let vid = v.g("id").s()[3..].to_string();
            if let Value::Object(m) = v {
                m.insert("video".into(), json!(true));
                m.insert("link".into(), json!(format!("https://www.youtube.com/watch?v={}", vid)));
                m.insert("thumb".into(), json!(format!("https://i.ytimg.com/vi/{}/mqdefault.jpg", vid)));
            }
        }
    }
    list.truncate(limit);
    Ok(list)
}

fn norm_a(s: &str) -> String {
    super::extras::name_key(s)
}

/// music videos of an artist — only the artist's own uploads
pub async fn clips(name: &str, limit: usize) -> R<Vec<Value>> {
    let n = norm_a(name);
    if n.is_empty() {
        return Ok(vec![]);
    }
    let list = search(name, 20, true).await?;
    Ok(list
        .into_iter()
        .filter(|v| {
            let d = v.g("duration").n();
            v.g("artists").arr().iter().any(|a| {
                let k = norm_a(&a.g("name").s());
                k == n || k == format!("{}vevo", n)
            }) && d >= 60.0
                && d <= 900.0
                && !re!(r"(?i)full album|greatest hits|playlist|сборник|\(lyrics\)|lyrics video|караоке|karaoke")
                    .is_match(&v.g("title").s())
        })
        .take(limit)
        .collect())
}

static CACHE: LazyLock<Mutex<(HashMap<String, (f64, Value)>, Vec<String>)>> =
    LazyLock::new(|| Mutex::new((HashMap::new(), vec![])));
const ITAGS: [i64; 5] = [251, 140, 250, 249, 139];

fn pick_audio(sd: &Value) -> Option<Value> {
    let list: Vec<&Value> = sd
        .g("adaptiveFormats")
        .arr()
        .iter()
        .filter(|f| f.g("mimeType").s().starts_with("audio/") && f.g("url").s().starts_with("https://"))
        .collect();
    for it in ITAGS {
        if let Some(f) = list.iter().find(|x| x.g("itag").as_i64() == Some(it)) {
            return Some((*f).clone());
        }
    }
    let mut l = list.clone();
    l.sort_by(|a, b| b.g("bitrate").n().partial_cmp(&a.g("bitrate").n()).unwrap_or(std::cmp::Ordering::Equal));
    l.first().map(|f| (*f).clone())
}

/// 4.20: without a proof-of-origin token YouTube gives only the first ~1 MB of a stream (the track stopped after
/// ~40 s with «Не удалось воспроизвести поток»). A small piece from the middle is asked first; a stream that refuses
/// it is not used, so the player takes the next source instead.
async fn whole_stream(f: &Value) -> bool {
    let url = f.g("url").s();
    let len: u64 = f.g("contentLength").s().parse().unwrap_or(0);
    if len <= 1_400_000 {
        return true; // a short file fits into the free first megabyte
    }
    let a = 1_048_576u64.min(len / 2);
    let r = crate::http::RAW
        .get(&url)
        .header("User-Agent", crate::http::UA)
        .header("Range", format!("bytes={}-{}", a, a + 299_999))
        .timeout(std::time::Duration::from_secs(8))
        .send()
        .await;
    matches!(r, Ok(r) if r.status().as_u16() == 206 || r.status().is_success())
}

pub async fn stream(id: &str) -> R<Value> {
    let vid = id.strip_prefix("yt:").unwrap_or(id).to_string();
    if !re!(r"^[A-Za-z0-9_-]{11}$").is_match(&vid) {
        return Err(E::new("Неверный id YouTube"));
    }
    if let Some((at, s)) = CACHE.lock().unwrap().0.get(&vid) {
        if now_ms() - at < 4.0 * 3600e3 {
            return Ok(s.clone());
        }
    }
    let mut f: Option<Value> = None;
    let mut err: Option<E> = None;
    let visitor = VISITOR.lock().unwrap().clone();
    for (client, num) in clients() {
        let mut c = client.clone();
        if !visitor.is_empty() {
            crate::js::set(&mut c, "visitorData", json!(visitor));
        }
        let mut o = Opts::new()
            .timeout(12000)
            .h("Content-Type", "application/json")
            .h("User-Agent", &client.g("userAgent").s())
            .h("Origin", "https://www.youtube.com")
            .h("X-YouTube-Client-Name", num)
            .h("X-YouTube-Client-Version", &client.g("clientVersion").s());
        if !visitor.is_empty() {
            o = o.h("X-Goog-Visitor-Id", &visitor);
        }
        let body = json!({ "context": { "client": c }, "videoId": vid, "contentCheckOk": true, "racyCheckOk": true });
        let res: R<Option<Value>> = async {
            let r = get_json(PLAYER, o.post(body.to_string())).await?;
            let ps = r.g("playabilityStatus");
            let st = ps.g("status");
            if st.truthy() && st.as_str() != Some("OK") {
                let reason = if ps.g("reason").truthy() { ps.g("reason").sv() } else { st.sv() };
                return Err(E::new(format!("YouTube: {}", slice(&reason, 120))));
            }
            Ok(pick_audio(r.g("streamingData")))
        }
        .await;
        match res {
            Ok(Some(x)) if whole_stream(&x).await => {
                f = Some(x);
                break;
            }
            Ok(Some(_)) => {
                err = Some(E::new("YouTube отдаёт только начало трека (нужно подтверждение PO-токеном) — пробую другой источник"))
            }
            Ok(None) => err = Some(E::new("YouTube не отдал аудиопоток этого трека")),
            Err(e) => {
                let keep = err.as_ref().map(|x| re!(r"(?i)LOGIN_REQUIRED|бот|bot").is_match(&x.msg)).unwrap_or(false);
                if !keep {
                    err = Some(e);
                }
            }
        }
    }
    let f = match f {
        Some(f) => f,
        None => return Err(err.unwrap_or_else(|| E::new("YouTube не отдал аудиопоток этого трека"))),
    };
    let br = if f.g("bitrate").truthy() { f.g("bitrate").n() } else { f.g("averageBitrate").n() };
    let kbps = round(if br.is_nan() { 0.0 } else { br } / 1000.0);
    let mime = f.g("mimeType").s();
    let mut q = Map::new();
    q.insert("codec".into(), json!(if mime.contains("opus") { "Opus" } else if mime.contains("mp4a") { "AAC" } else { "" }));
    q.insert("kbps".into(), if kbps != 0.0 { jn(kbps) } else { Value::Null });
    q.insert("src".into(), json!("YouTube Music"));
    let ad = f.g("approxDurationMs");
    let s = json!({
        "url": f.g("url"),
        "type": "file",
        "preview": false,
        "duration": if ad.truthy() { jn(round(ad.n() / 1000.0)) } else { Value::Null },
        "q": Value::Object(q),
        "youtube": true,
    });
    let mut c = CACHE.lock().unwrap();
    if !c.0.contains_key(&vid) {
        c.1.push(vid.clone());
    }
    c.0.insert(vid, (now_ms(), s.clone()));
    if c.0.len() > 300 {
        let first = c.1.remove(0);
        c.0.remove(&first);
    }
    Ok(s)
}

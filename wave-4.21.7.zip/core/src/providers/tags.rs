//! Minimal tag reader for uploaded audio files: title / artist / album / cover. ID3v2.2–2.4 (also in AIFF / WAV
//! chunks), ID3v1, FLAC & Ogg (Vorbis / Opus) comments, MP4 ilst, WAV LIST/INFO; else «Artist - Title» of the name.

use crate::re;
use std::io::{Read, Seek, SeekFrom};
use std::path::Path;

const MAX: usize = 24 * 1024 * 1024;

#[derive(Default, Debug)]
pub struct Tags {
    pub title: String,
    pub artist: String,
    pub album: String,
    pub cover: Option<(String, Vec<u8>)>,
}

fn latin1(b: &[u8]) -> String {
    b.iter().map(|&c| c as char).collect()
}
fn until0(s: &str) -> &str {
    s.split('\0').next().unwrap_or("")
}
fn dec(buf: &[u8], enc: u8) -> String {
    if enc == 1 || enc == 2 {
        let mut b = buf;
        let mut le = enc == 1;
        if b.len() >= 2 && b[0] == 0xff && b[1] == 0xfe {
            le = true;
            b = &b[2..];
        } else if b.len() >= 2 && b[0] == 0xfe && b[1] == 0xff {
            le = false;
            b = &b[2..];
        }
        let u: Vec<u16> = b
            .chunks_exact(2)
            .map(|c| if le { u16::from_le_bytes([c[0], c[1]]) } else { u16::from_be_bytes([c[0], c[1]]) })
            .collect();
        let s = String::from_utf16_lossy(&u);
        return until0(s.trim_end_matches('\0')).to_string();
    }
    if enc == 3 {
        let s = String::from_utf8_lossy(buf);
        return until0(s.trim_end_matches('\0')).to_string();
    }
    // ISO-8859-1 … but many Russian files are really cp1251
    let s = until0(&latin1(buf)).to_string();
    let hi = s.chars().filter(|c| ('\u{C0}'..='\u{FF}').contains(c)).count();
    let has_run = re!(r"[\xC0-\xFF]{2,}").is_match(&s);
    if has_run && hi > 0 && !s.chars().any(|c| ('\u{80}'..='\u{BF}').contains(&c)) {
        let bytes: Vec<u8> = s.chars().map(|c| c as u32 as u8).collect();
        return encoding_rs::WINDOWS_1251.decode(&bytes).0.into_owned();
    }
    s
}
fn clean(s: &str) -> String {
    let s: String = s.chars().map(|c| if (c as u32) < 0x20 { ' ' } else { c }).collect();
    crate::js::slice(s.trim(), 300)
}
fn syncsafe(b: &[u8], o: usize) -> usize {
    if o + 4 > b.len() {
        return 0;
    }
    ((b[o] as usize & 0x7f) << 21) | ((b[o + 1] as usize & 0x7f) << 14) | ((b[o + 2] as usize & 0x7f) << 7) | (b[o + 3] as usize & 0x7f)
}
fn u32be(b: &[u8], o: usize) -> Option<usize> {
    b.get(o..o + 4).map(|x| u32::from_be_bytes([x[0], x[1], x[2], x[3]]) as usize)
}
fn u32le(b: &[u8], o: usize) -> Option<usize> {
    b.get(o..o + 4).map(|x| u32::from_le_bytes([x[0], x[1], x[2], x[3]]) as usize)
}
fn set(f: &mut String, v: String) {
    if f.is_empty() {
        *f = v;
    }
}

fn id3v2(b: &[u8], out: &mut Tags) -> bool {
    if b.len() < 10 || &b[..3] != b"ID3" {
        return false;
    }
    let ver = b[3];
    let flags = b[5];
    let size = syncsafe(b, 6);
    let mut o = 10;
    let end = b.len().min(10 + size);
    if flags & 0x40 != 0 && ver >= 3 {
        o += if ver == 4 { syncsafe(b, o) } else { u32be(b, o).unwrap_or(0) + 4 };
    }
    let id_len = if ver == 2 { 3 } else { 4 };
    let hdr = if ver == 2 { 6 } else { 10 };
    while o + hdr <= end {
        let id = latin1(&b[o..o + id_len]);
        if !re!(r"^[A-Z0-9]{3,4}$").is_match(&id) {
            break;
        }
        let len = if ver == 2 {
            ((b[o + 3] as usize) << 16) | ((b[o + 4] as usize) << 8) | b[o + 5] as usize
        } else if ver == 4 {
            syncsafe(b, o + 4)
        } else {
            u32be(b, o + 4).unwrap_or(0)
        };
        if len == 0 || o + hdr + len > end {
            break;
        }
        let f = &b[o + hdr..o + hdr + len];
        let enc = f[0];
        match id.as_str() {
            "TIT2" | "TT2" => set(&mut out.title, clean(&dec(&f[1..], enc))),
            "TPE1" | "TP1" => set(&mut out.artist, clean(&dec(&f[1..], enc))),
            "TALB" | "TAL" => set(&mut out.album, clean(&dec(&f[1..], enc))),
            "APIC" | "PIC" if out.cover.is_none() => {
                let (mime, mut p);
                if id == "PIC" {
                    mime = if latin1(&f[1..4.min(f.len())]).to_lowercase().contains("png") { "image/png".to_string() } else { "image/jpeg".to_string() };
                    p = 4;
                } else {
                    let z = f[1..].iter().position(|&c| c == 0).map(|x| x + 1).unwrap_or(f.len());
                    let m = latin1(&f[1..z]);
                    mime = if m.is_empty() { "image/jpeg".into() } else { m };
                    p = z + 1;
                }
                p += 1;
                if enc == 1 || enc == 2 {
                    while p + 1 < f.len() && !(f[p] == 0 && f[p + 1] == 0) {
                        p += 2;
                    }
                    p += 2;
                } else {
                    while p < f.len() && f[p] != 0 {
                        p += 1;
                    }
                    p += 1;
                }
                if p < f.len() {
                    out.cover = Some((mime, f[p..].to_vec()));
                }
            }
            _ => {}
        }
        o += hdr + len;
    }
    true
}
fn id3v1(file: &mut std::fs::File, size: u64, out: &mut Tags) {
    if size < 128 || (!out.title.is_empty() && !out.artist.is_empty()) {
        return;
    }
    let mut b = [0u8; 128];
    if file.seek(SeekFrom::Start(size - 128)).is_err() || file.read_exact(&mut b).is_err() {
        return;
    }
    if &b[..3] != b"TAG" {
        return;
    }
    set(&mut out.title, clean(&dec(&b[3..33], 0)));
    set(&mut out.artist, clean(&dec(&b[33..63], 0)));
    set(&mut out.album, clean(&dec(&b[63..93], 0)));
}
fn vorbis_comments(c: &[u8], out: &mut Tags) {
    let Some(vlen) = u32le(c, 0) else { return };
    let mut o = 4 + vlen;
    let Some(n) = u32le(c, o) else { return };
    o += 4;
    let mut i = 0;
    while i < n && o + 4 <= c.len() {
        let l = u32le(c, o).unwrap_or(0);
        o += 4;
        let s = String::from_utf8_lossy(&c[o.min(c.len())..(o + l).min(c.len())]).into_owned();
        o += l;
        i += 1;
        let Some(k) = s.find('=') else { continue };
        let key = s[..k].to_uppercase();
        let v = clean(&s[k + 1..]);
        match key.as_str() {
            "TITLE" => set(&mut out.title, v),
            "ARTIST" => set(&mut out.artist, v),
            "ALBUM" => set(&mut out.album, v),
            "METADATA_BLOCK_PICTURE" if out.cover.is_none() => {
                use base64::Engine;
                if let Ok(p) = base64::engine::general_purpose::STANDARD.decode(s[k + 1..].trim()) {
                    flac_picture(&p, out);
                }
            }
            _ => {}
        }
    }
}
fn flac_picture(p: &[u8], out: &mut Tags) {
    let r = (|| {
        let mut o = 4;
        let ml = u32be(p, o)?;
        let mime = latin1(p.get(o + 4..o + 4 + ml)?);
        o += 4 + ml;
        let dl = u32be(p, o)?;
        o += 4 + dl + 16;
        let len = u32be(p, o)?;
        let data = p.get(o + 4..(o + 4 + len).min(p.len()))?.to_vec();
        Some((if mime.is_empty() { "image/jpeg".to_string() } else { mime }, data))
    })();
    if let Some(c) = r {
        out.cover = Some(c);
    }
}
fn flac(b: &[u8], out: &mut Tags) {
    let mut o = 4;
    while o + 4 <= b.len() {
        let last = b[o] & 0x80 != 0;
        let ty = b[o] & 0x7f;
        let len = ((b[o + 1] as usize) << 16) | ((b[o + 2] as usize) << 8) | b[o + 3] as usize;
        let blk = &b[(o + 4).min(b.len())..(o + 4 + len).min(b.len())];
        if ty == 4 {
            vorbis_comments(blk, out);
        } else if ty == 6 && out.cover.is_none() {
            flac_picture(blk, out);
        }
        o += 4 + len;
        if last {
            break;
        }
    }
}
fn find(h: &[u8], n: &[u8]) -> Option<usize> {
    h.windows(n.len()).position(|w| w == n)
}
fn ogg(b: &[u8], out: &mut Tags) {
    let mut all = vec![];
    let mut o = 0;
    let mut n = 0;
    while n < 40 && o + 27 <= b.len() && &b[o..o + 4] == b"OggS" {
        let segs = b[o + 26] as usize;
        let mut len = 0;
        for i in 0..segs {
            len += *b.get(o + 27 + i).unwrap_or(&0) as usize;
        }
        let s = (o + 27 + segs).min(b.len());
        all.extend_from_slice(&b[s..(s + len).min(b.len())]);
        o += 27 + segs + len;
        n += 1;
    }
    if let Some(i) = find(&all, b"\x03vorbis") {
        return vorbis_comments(&all[i + 7..], out);
    }
    if let Some(i) = find(&all, b"OpusTags") {
        vorbis_comments(&all[i + 8..], out);
    }
}
fn mp4_walk(b: &[u8], s: usize, e: usize, want: &[&str]) -> Option<(usize, usize)> {
    let mut o = s;
    while o + 8 <= e {
        let mut size = u32be(b, o)?;
        let ty = latin1(&b[o + 4..o + 8]);
        if size == 1 {
            size = b.get(o + 8..o + 16).map(|x| u64::from_be_bytes(x.try_into().unwrap()) as usize)?;
        }
        if size < 8 || o + size > e {
            size = e - o;
        }
        if ty == want[0] {
            if want.len() == 1 {
                return Some((o, o + size));
            }
            let off = if ty == "meta" { 12 } else { 8 };
            return mp4_walk(b, o + off, o + size, &want[1..]);
        }
        o += size;
    }
    None
}
fn mp4(b: &[u8], out: &mut Tags) {
    let Some(ilst) = mp4_walk(b, 0, b.len(), &["moov", "udta", "meta", "ilst"]) else { return };
    let mut o = ilst.0 + 8;
    while o + 8 <= ilst.1 {
        let Some(size) = u32be(b, o) else { break };
        if size < 8 {
            break;
        }
        let key = latin1(&b[o + 4..o + 8]);
        if let Some(d) = mp4_walk(b, o + 8, (o + size).min(b.len()), &["data"]) {
            let kind = u32be(b, d.0 + 8).unwrap_or(0) & 0xffffff;
            let v = &b[(d.0 + 16).min(d.1)..d.1];
            let txt = || clean(&String::from_utf8_lossy(v));
            match key.as_str() {
                "\u{a9}nam" => set(&mut out.title, txt()),
                "\u{a9}ART" | "aART" => set(&mut out.artist, txt()),
                "\u{a9}alb" => set(&mut out.album, txt()),
                "covr" if out.cover.is_none() => {
                    out.cover = Some((if kind == 14 { "image/png" } else { "image/jpeg" }.to_string(), v.to_vec()))
                }
                _ => {}
            }
        }
        o += size;
    }
}
fn riff(b: &[u8], out: &mut Tags) {
    let mut o = 12;
    while o + 8 <= b.len() {
        let id = latin1(&b[o..o + 4]);
        let len = u32le(b, o + 4).unwrap_or(0);
        if id == "LIST" && b.get(o + 8..o + 12) == Some(b"INFO") {
            let mut p = o + 12;
            while p + 8 <= (o + 8 + len).min(b.len()) {
                let k = latin1(&b[p..p + 4]);
                let l = u32le(b, p + 4).unwrap_or(0);
                let v = clean(&dec(&b[(p + 8).min(b.len())..(p + 8 + l).min(b.len())], 3));
                match k.as_str() {
                    "INAM" => set(&mut out.title, v),
                    "IART" => set(&mut out.artist, v),
                    "IPRD" => set(&mut out.album, v),
                    _ => {}
                }
                p += 8 + l + (l & 1);
            }
        } else if (id == "id3 " || id == "ID3 ") && b.len() >= o + 8 + 10 {
            id3v2(&b[o + 8..(o + 8 + len).min(b.len())], out);
        }
        o += 8 + len + (len & 1);
    }
}

pub fn from_name(file: &Path) -> (String, String) {
    let stem = file.file_stem().map(|s| s.to_string_lossy().into_owned()).unwrap_or_default();
    let n = re!(r"_+").replace_all(&stem, " ");
    let n = re!(r"\s+").replace_all(&n, " ").trim().to_string();
    let n = re!(r"^\d{1,3}\s*[.\-)]\s*").replacen(&n, 1, "").into_owned();
    if let Some(m) = re!(r"^(.+?)\s+[-–—]\s+(.+)$").captures(&n) {
        return (m[1].trim().to_string(), m[2].trim().to_string());
    }
    (String::new(), n)
}

pub fn read(file: &Path) -> Tags {
    let mut out = Tags::default();
    let _ = (|| -> std::io::Result<()> {
        let mut fh = std::fs::File::open(file)?;
        let size = fh.metadata()?.len();
        let mut b = vec![0u8; (size as usize).min(MAX)];
        fh.read_exact(&mut b)?;
        let magic = if b.len() >= 4 { latin1(&b[..4]) } else { String::new() };
        if magic == "fLaC" {
            flac(&b, &mut out);
        } else if magic == "OggS" {
            ogg(&b, &mut out);
        } else if magic == "RIFF" || magic == "FORM" {
            riff(&b, &mut out);
        } else if b.len() >= 8 && &b[4..8] == b"ftyp" {
            mp4(&b, &mut out);
        } else if magic.starts_with("ID3") {
            id3v2(&b, &mut out);
            let sz = 10 + syncsafe(&b, 6);
            if b.get(sz..sz + 4) == Some(b"fLaC") {
                flac(&b[sz..], &mut out);
            }
        }
        if magic != "fLaC" && magic != "OggS" {
            id3v1(&mut fh, size, &mut out);
        }
        Ok(())
    })();
    let (a, t) = from_name(file);
    if out.title.is_empty() {
        out.title = t;
    }
    if out.artist.is_empty() {
        out.artist = a;
    }
    if let Some((_, d)) = &out.cover {
        if d.len() < 64 || d.len() > 8 * 1024 * 1024 {
            out.cover = None;
        }
    }
    out
}

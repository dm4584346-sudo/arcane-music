"use strict";
/* Wave Android — ТЗ 3.1.1: форма «Сообщить об ошибке».
   Собирает: описание пользователя + модель телефона и версию Android (из userAgent WebView),
   версию Wave (NATIVE.version() / S.version) и хвост журнала ядра (команда api("logs") → data/startup.log).
   Отправка — сценарий Б ТЗ: текст кладётся в буфер обмена и открывается канал разработчика в Telegram.
   Точка входа — строка в карточке «О программе» настроек (через хук window.waveExtraSettings из app.js). */
(() => {
  const root = document.documentElement;
  if (!root.hasAttribute("data-mobile")) return;

  const NATIVE = window.WaveAndroid || null;
  // the report goes to the developer in person (his choice: the chat with @XANTEPMK, not the channel)
  const CHANNEL_URL = "https://t.me/XANTEPMK";

  /* модель и версия Android из userAgent WebView: "…(Linux; Android 14; SM-A536B Build/…; wv)…" */
  function deviceInfo() {
    const ua = navigator.userAgent || "";
    const m = /\(([^)]*)\)/.exec(ua);
    let android = "неизвестно", model = "неизвестно";
    if (m) {
      const parts = m[1].split(";").map((s) => s.trim());
      const ai = parts.findIndex((p) => /^Android/.test(p));
      if (ai >= 0) {
        android = (/^Android\s+([0-9.]+)/.exec(parts[ai]) || [])[1] || "неизвестно";
        for (let i = ai + 1; i < parts.length; i++) {
          const p = parts[i];
          if (!p || p === "wv" || /^Build\//.test(p)) continue;
          model = p.replace(/\s*Build\/.*$/i, "").trim() || "неизвестно";
          break;
        }
      }
    }
    return { android, model };
  }

  /* данные отчёта: собираются один раз на открытие формы (журнал идёт через ядро) */
  let infoP = null;
  const collect = () => {
    if (!infoP)
      infoP = (async () => {
        const dev = deviceInfo();
        const wave = (NATIVE && typeof NATIVE.version === "function" && NATIVE.version()) || S.version || "неизвестно";
        let log = "";
        try {
          log = (await api("logs")).log || "";
        } catch {
          log = "";
        }
        return { dev, wave, log: log.trim() };
      })();
    return infoP;
  };

  /* полный текст отчёта; Telegram не принимает длиннее 4096 символов — ужимаем журнал */
  function compose(text, info) {
    let log = info.log || "";
    let msg =
      `#wavebug\nОписание: ${(text || "").trim() || "(не указано)"}\n\n` +
      `Устройство: ${info.dev.model}\nAndroid: ${info.dev.android}\nWave: ${info.wave}\n\n` +
      (log ? "Журнал (последние строки):\n" + log : "Журнал недоступен");
    const cap = 3800;
    if (msg.length > cap) {
      const head = msg.length - log.length;
      const budget = cap - head - 40;
      if (budget > 200) {
        log = log.slice(log.length - budget);
        const nl = log.indexOf("\n");
        if (nl >= 0) log = log.slice(nl + 1);
        msg = msg.slice(0, head) + "…\n" + log;
      } else {
        msg = msg.slice(0, cap);
      }
    }
    return msg;
  }

  function copyText(text) {
    if (NATIVE && typeof NATIVE.copy === "function") return Promise.resolve(NATIVE.copy(text));
    return navigator.clipboard?.writeText(text).catch(() => {
      /* резерв без clipboard API: скрытая textarea + execCommand (работает внутри жеста) */
      const ta = document.createElement("textarea");
      ta.value = text;
      ta.style.cssText = "position:fixed;opacity:0";
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
      } finally {
        ta.remove();
      }
    });
  }

  // 4.20.1: the chat opens with the report already typed in the message field (t.me/<user>?text=…) — only «Отправить»
  // is left; the copy in the clipboard stays as a spare (a long log is cut in the link, the full one is in the clipboard)
  function openChat(text) {
    let url = CHANNEL_URL;
    if (text) {
      const t = text.length > 1800 ? text.slice(0, 1800) + "\n…(полный отчёт в буфере обмена)" : text;
      url += "?text=" + encodeURIComponent(t);
    }
    if (NATIVE && typeof NATIVE.openUrl === "function") NATIVE.openUrl(url);
    else window.open(url, "_blank");
  }

  let el = null;
  const close = () => {
    if (!el) return;
    const x = el;
    el = null;
    x.classList.add("out");
    setTimeout(() => x.remove(), 320);
  };

  async function open() {
    close();
    infoP = null;
    el = document.createElement("div");
    el.className = "rp";
    el.id = "report";
    el.setAttribute("role", "dialog");
    el.setAttribute("aria-label", "Сообщить об ошибке");
    el.innerHTML =
      `<div class="rp-card">` +
      `<button class="rp-x" data-rp-cancel aria-label="Закрыть"><svg viewBox="0 0 24 24" fill="none"><path d="M6 6l12 12M18 6L6 18" stroke="currentColor" stroke-width="2" stroke-linecap="round"/></svg></button>` +
      `<h2>Сообщить об ошибке</h2>` +
      `<p>Опишите, что произошло. Модель телефона, версия Android, версия Wave и последние строки журнала приложатся автоматически.</p>` +
      `<textarea class="rp-ta" placeholder="Что случилось? Какие шаги к этому привели?"></textarea>` +
      `<details class="rp-meta"><summary>Что приложится к отчёту</summary><pre>Собираю данные…</pre></details>` +
      `<div class="rp-btns">` +
      `<button class="rp-btn acc" data-rp-send>Отправить в Telegram</button>` +
      `<div class="rp-row"><button class="rp-btn ghost" data-rp-copy>Скопировать</button><button class="rp-btn ghost" data-rp-cancel>Отмена</button></div>` +
      `</div></div>`;
    document.body.appendChild(el);
    const ta = el.querySelector(".rp-ta");
    const pre = el.querySelector(".rp-meta pre");
    collect()
      .then((i) => {
        if (!el) return;
        pre.textContent = `Устройство: ${i.dev.model}\nAndroid: ${i.dev.android}\nWave: ${i.wave}\n\n${i.log || "журнал пуст или недоступен"}`;
      })
      .catch(() => {
        if (el) pre.textContent = "Не удалось собрать данные";
      });
    el.addEventListener("click", async (e) => {
      if (e.target.closest("[data-rp-cancel]")) return close();
      if (e.target === el) return close();
      if (e.target.closest("[data-rp-copy]")) {
        await copyText(compose(ta.value, await collect()));
        toast("Скопировано", 3000);
        return;
      }
      if (e.target.closest("[data-rp-send]")) {
        const b = e.target.closest("[data-rp-send]");
        b.disabled = true;
        b.textContent = "Готовлю…";
        try {
          const full = compose(ta.value, await collect());
          await Promise.resolve(copyText(full)).catch(() => {});
          openChat(full);
          toast("Откроется чат — текст уже набран, нажмите «Отправить»", 6000);
          close();
        } catch (err) {
          toast("Не удалось отправить: " + (err && err.message ? err.message : "ошибка"), 5000);
          b.disabled = false;
          b.textContent = "Отправить в Telegram";
        }
      }
    });
  }

  /* строки в карточке «О программе» — app.js вызывает это после сборки мобильных настроек */
  window.waveExtraSettings = (st) => {
    const card = [...st.querySelectorAll(".scard")].find(
      (c) => (c.querySelector("h2")?.textContent || "").trim() === "О программе",
    );
    if (!card || card.querySelector("[data-rp-open]")) return;
    card.insertAdjacentHTML(
      "beforeend",
      `<div class="row"><div class="lbl"><b>Сообщить об ошибке</b><small>Соберём модель телефона, Android, версию Wave и журнал — отправите в Telegram</small></div><button class="btn sm acc" data-rp-open>Открыть</button></div>` +
        `<div class="row"><div class="lbl"><b>Проверить обновления</b><small>Новые версии публикуются в Telegram-канале Wave</small></div><button class="btn sm ghost" data-upd-check>Проверить</button></div>`,
    );
    card.querySelector("[data-rp-open]").onclick = () => open();
    card.querySelector("[data-upd-check]").onclick = () => window.waveUpd?.check(true);
  };
})();

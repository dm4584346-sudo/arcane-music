/* Wave iOS 4.21.5 — lock screen buttons and lyrics retries */
(function () {
  const ios = document.documentElement.classList.contains("wave-ios") || /iPhone|iPad|iPod/.test(navigator.userAgent);
  if (!ios) return;
  const ok = (f) => { try { return f(); } catch (e) { return undefined; } };
  const rem = (a) => {
    if (window.waveRemote) return window.waveRemote(a, 0);
    if (a === "next") ok(() => next());
    else if (a === "prev") ok(() => prev());
  };
  /* lock screen: «previous» / «next» buttons instead of ±10 seconds */
  function session() {
    const m = navigator.mediaSession;
    if (!m) return;
    ok(() => m.setActionHandler("previoustrack", () => rem("prev")));
    ok(() => m.setActionHandler("nexttrack", () => rem("next")));
    ok(() => m.setActionHandler("seekbackward", null));
    ok(() => m.setActionHandler("seekforward", null));
    /* 4.21.6: the progress bar on the lock screen can be dragged with a finger */
    ok(() => m.setActionHandler("seekto", (d) => {
      if (!d || d.seekTime == null) return;
      if (window.waveRemote) window.waveRemote("seek", Math.round(d.seekTime * 1000));
      else { const a = document.querySelector("audio"); if (a) a.currentTime = d.seekTime; }
      pos(true);
    }));
  }
  let posT = 0;
  function pos(force) {
    const m = navigator.mediaSession, now = Date.now();
    if (!m || !m.setPositionState || (!force && now - posT < 1000)) return;
    posT = now;
    const a = [...document.querySelectorAll("audio")].find((x) => !x.paused) || document.querySelector("audio");
    if (!a || !isFinite(a.duration) || a.duration <= 0) return;
    ok(() => m.setPositionState({ duration: a.duration, position: Math.min(a.currentTime, a.duration), playbackRate: a.paused ? 0 : a.playbackRate || 1 }));
  }
  ["timeupdate", "seeked", "loadedmetadata", "play", "pause"].forEach((ev) =>
    document.addEventListener(ev, (e) => e.target && e.target.tagName === "AUDIO" && pos(ev !== "timeupdate"), true));
  session();
  let last = null;
  setInterval(() => ok(() => {
    const id = S.current && S.current.id;
    if (id && id !== last) { last = id; session(); }
  }), 700);
  /* lyrics: a search that failed because of the network is not remembered as «no text» — it is asked again */
  ok(() => {
    const c = LY.cache, set = c.set.bind(c);
    c.set = (k, v) => (v && v.notFound && Array.isArray(v.errors) && v.errors.length ? c : set(k, v));
  });
})();
